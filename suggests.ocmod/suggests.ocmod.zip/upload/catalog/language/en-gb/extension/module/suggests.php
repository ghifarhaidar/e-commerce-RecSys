<?php
// Heading
$_['heading_title'] = 'Suggests';

// Text
$_['text_tax']      = 'Ex Tax:';